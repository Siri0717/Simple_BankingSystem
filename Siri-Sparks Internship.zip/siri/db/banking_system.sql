-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2020 at 05:16 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banking_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `account_number` int(11) NOT NULL,
  `account_type` varchar(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phno` bigint(20) NOT NULL,
  `address` text NOT NULL,
  `cur_balance` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`account_number`, `account_type`, `name`, `email`, `phno`, `address`, `cur_balance`) VALUES
(1, 'current', 'Jhon', 'Jhondab@yahoo.com', 7894561230, '#40 Dubai UAE', 50000),
(2, 'current', 'Arjun', 'arjun123@23.com', 9988775123, '#567 Pune india.', 10000),
(3, 'savings', 'Elle', 'ellezille@htmail.com', 8796231450, 'Los Angeles, US', 40000),
(4, 'savings', 'Abhishek', 'abhidude@htmail.com', 7546981022, 'Near DPS School, Bengaluru India', 25000),
(5, 'savings', 'Janavi', 'janavikr@23.com', 7468775522, '#789 washington DC, America', 90000),
(6, 'current', 'Seema', 'seemasharma@yahoo.com', 9600235884, '#1001 Surya Mahal, AP', 70000),
(7, 'current', 'Rohan', 'rohandecaprio@yahoo.com', 9152365800, '#987 Opp to Sri Ram Mandir,Uttar Pradesh', 80000),
(8, 'savings', 'Amelie', 'ameliezilberg@23.com', 9511418223, '#420, Delhi, India', 40000),
(9, 'savings', 'Krishna Nagrajam', 'krishnanagrajam@34.com', 7788892210, 'Gujarat, India ', 30000),
(10, 'current', 'Mouli', 'mouli@34.com', 6454242456, '#kerala, India', 60000);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `from_account_no` int(11) NOT NULL,
  `to_account_no` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `message` text NOT NULL,
  `amount_sent` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`account_number`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `account_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
